#!/usr/bin/env node

function scopeAst (name, x) {
    this.name = name;
    this.x = x;
}

function compile (ast) {
    var name = ast.name;
    var args = [];
    var i;
    var arg;
    for (i = 0; i < ast.x.length; i += 1) {
        if (typeof ast.x[i] === "string") {
            arg = ast.x[i];
        } else {
            arg = compile(ast.x[i]);
        }
        args.push(arg);
    }
    if (fs.existsSync(__dirname + '/rules/' + name + '.js')) {
        return require(__dirname + '/rules/' + name).apply(program_data, args);
    } else {
        throw '`' + name + '(' + args.join(', ') + ')` is not implemented';
    }
}

// return the indented AST
scopeAst.prototype.get = function get (indent) {
    // create an indentation for level l
    function indentString(l) {
        var r="";
        for(var i=0; i<l; i += 1) {
            r += i + " ";
        }
        return r;
    }

    var r = indentString(indent) + "(" + this.name;
    var rem = this.x;
    if(rem.length == 1 && !(rem[0] instanceof scopeAst)) {
        r += " '"+rem[0]+"'";
    } else for( i in rem ) {
        if( rem[i] instanceof scopeAst ) {
            r += "\n" + rem[i].get(indent+1);
        } else {
            r += "\n" + indentString(indent+1);
            r += "'"+rem[i]+"'";
        }
    }
    return r + /*"\n" + indentString(indent) +*/ ")";
}

var ast, code, hasSlash;
var options = {};
var options_regex = /^[a-z]+\=.*$/;
var args = process.argv.map(function (arg) {
    if (options_regex.test(arg)) {
        options[arg.substr(0, arg.indexOf('='))] =
            arg.substr(arg.indexOf('=')+1, arg.length);
    } else {
        return arg;
    }
});
args.forEach(function (val, i) {
    if (val === void 0) {
        args.splice(i, 1);
    }
});
var scope = require(__dirname + '/scope.js');
var fs = require('fs');
var scope_file = fs.readFileSync(args[2], "utf8");
var pretty = (new (require('node-js-beautify'))()).beautify_js;
var ugly = require('uglify-js').minify;
var filename = args[3] ||
    (
        ((hasSlash = args[2].lastIndexOf('/')) === -1) ?
        args[2] :
        (args[2].substr(
            hasSlash + 1,
            args[2].length - 1
        ))
    ).replace('.sc','.js');
var file = process.cwd() + "/" + filename;
var program_data = {compile: compile, curParent: -1, lastParent: [-1]}

scope.parser.yy.scopeAst = scopeAst;
ast = scope.parse(scope_file)

if (options['code'] === 'ast') {
    console.log(ast.get(0));
    return;
}

program_data.parse = scope.parse;
code = compile(ast);
code = 'function $$$concat(a, b) {' +
'    var result, shortest, i;' +
'    if (' +
'        !(typeof a === "string" && typeof b === "string") &&' +
'        !(typeof a === "object" && typeof b === "object")' +
'    ) {' +
'        throw "Both types must be the same (either string or array)";' +
'    }' +
'    if (typeof a === "string") {' +
'        result = a + b;' +
'    } else {' +
'        if(a instanceof Array) {' +
'            for (i = 0; i < b.length; i += 1) {' +
'                a.push(b[i]);' +
'            }' +
'            result = a;' +
'        } else {' +
'            if (a.length > b.length) {' +
'                result = a;' +
'                shortest = b;' +
'            } else {' +
'                result = b;' +
'                shortest = a;' +
'            }' +
'            for (i in shortest) {' +
'                if(i !== "length" && shortest.hasOwnProperty(i)) {' +
'                    result[i] = shortest[i];' +
'                    result.length += 1;' +
'                }' +
'            }' +
'        }' +
'    }' +
'    return result;' +
'};' + code;

//console.log(pretty(code));
//return;
if (options['code'] === "pretty") {
    code = pretty(code);
} else if (options['code'] === "bloated") {

} else {
    code = ugly(code, {fromString: true}).code;
}
/*
console.log(JSON.stringify(ast, null, ' '));

console.log(scope.parse(
    fs.readFileSync(process.argv[2], "utf8")
).get(0));
*/




console.log("File:", file);



fs.writeFileSync(file, "#!/usr/bin/env node\n" + code);

fs.chmodSync(file, '0755');
console.log("Compiled to " + file);
