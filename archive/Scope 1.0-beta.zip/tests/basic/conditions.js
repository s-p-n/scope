#!/usr/bin/env node
function self(o, e, f) {
    return void 0 === e ? selfProps[o] : void 0 === f ? (void 0 === selfProps[o] && (selfProps.access[o] = "private"), selfProps[o] = e, e) : (selfProps.access[e] = o, selfProps[e] = f, f)
}
var selfProps = {
    access: {}
},
    foo = function() {
        return 8 + 240 / function() {
            var o, e = 5;
            for (o = 1; 5 > o; o += 1) e *= o;
            return e
        }()
    }();
!function() {
    console.log.apply(null, Array.prototype.slice.call(arguments, arguments))
}("foo is 10?", function() {
    return 10 === ("undefined" == typeof foo ? self("foo") : foo) ? function() {
        return "yes"
    }() : function() {
        return "no"
    }()
}(), "Check: " + ("undefined" == typeof foo ? self("foo") : foo));