module.exports = function (a, b) {
    if (b === void 0) {
        return "return " + a;
    } else {
        return "return " + b;
    }
}
