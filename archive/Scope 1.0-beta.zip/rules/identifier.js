var Variables = {
    Console: {
        write: function () {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        }
    }
};
module.exports = function identifier (id, name, isArr) {
    if (name !== void 0) {
        if (typeof id === "object") {
            if (name in id) {
                return id[name];
            } else {
                throw '"'+name+'" is not a member of "' + id + '"';
            }
        }
        if (isArr !== void 0) {
            return id + '[' + name + ']';
        }
        return id + '.' + name;
    }
    if (id in Variables) {
        return Variables[id];
    }
    return '(typeof '+id+' === "undefined" ? self("'+id+'") : '+id+')';
}
