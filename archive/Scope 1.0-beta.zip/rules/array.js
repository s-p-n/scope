module.exports = function array(arr) {
    return arr || "[]";
}
