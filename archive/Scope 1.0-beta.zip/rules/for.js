module.exports = function _for (forBegin, controlBlock, loopElse) {
    return forBegin + controlBlock + loopElse + "}());}}}())";
}
