module.exports = function conditional (cond) {
    return cond;
}
