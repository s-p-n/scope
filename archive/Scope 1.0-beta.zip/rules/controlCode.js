module.exports = function controlCode (controlCode, stmt) {
    if (controlCode === void 0) {
        if (this.parentId === void 0) {
            this.parentId = 0;
        } else {
            this.parentId += 1;
        }
        return 'function self(o,e,f){' +
        '   return void 0===e ?' +
        '       selfProps[o] :' +
        '   void 0===f ?' +
        '   ('+
        '       void 0===selfProps[o]&&' +
        '       (selfProps.access[o]="private"),' +
        '       selfProps[o]=e,'+
        '       e'+
        '   ) : ('+
        '       selfProps.access[e]=o,'+
        '       selfProps[e]=f,'+
        '       f'+
        '   )'+
        '};' +
        'var selfProps={access:{parent: "private"},parent:' + (this.curParent > -1 ? ("$$$parent" + this.curParent) : "null") + '};' +
        'var $$$parent' + this.parentId + '=selfProps;';
    }

    return controlCode + stmt + ';';
}
