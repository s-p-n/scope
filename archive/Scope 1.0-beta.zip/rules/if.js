module.exports = function _if (ifBegin, controlBlock, ifElse) {
    return ifBegin + controlBlock + ifElse;
}
