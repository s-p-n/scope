module.exports = function declareVariable(name, val) {
    return "var " + name + "=" + val;
}
