var $$$concat = function (a, b) {
    var result, shortest, i;
    if (
        !(typeof a === "string" && typeof b === "string") &&
        !(typeof a === "object" && typeof b === "object")
    ) {
        throw "Both types must be the same (either string or array)";
    }
    if (typeof a === "string") {
        result = a + b;
    } else {
        if(a instanceof Array) {
            for (i = 0; i < b.length; i += 1) {
                a.push(b[i]);
            }
            result = a;
        } else {
            if (a.length > b.length) {
                result = a;
                shortest = b;
            } else {
                result = b;
                shortest = a;
            }
            for (i in shortest) {
                if(i !== "length" && shortest.hasOwnProperty(i)) {
                    result[i] = shortest[i];
                    result.length += 1;
                }
            }
        }
    }
    return result;
};