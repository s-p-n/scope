#!/usr/bin/env node
var $$$concat = function(a, b) {
    var result, shortest, i;
    if (!(typeof a === "string" && typeof b === "string") && !(typeof a === "object" && typeof b === "object")) {
        throw "Both types must be the same (either string or array)";
    }
    if (typeof a === "string") {
        result = a + b;
    } else {
        if (a instanceof Array) {
            for (i = 0; i < b.length; i += 1) {
                a.push(b[i]);
            }
            result = a;
        } else {
            if (a.length > b.length) {
                result = a;
                shortest = b;
            } else {
                result = b;
                shortest = a;
            }
            for (i in shortest) {
                if (i !== "length" && shortest.hasOwnProperty(i)) {
                    result[i] = shortest[i];
                    result.length += 1;
                }
            }
        }
    }
    return result;
};
var Console = function() {
    return {
        write: function() {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        },
        read: function(callback) {
            var rl = require('readline').createInterface({
                input: process.stdin,
                output: process.stdout
            })
            rl.on('line', function(line) {
                if (typeof callback === 'function') {
                    callback(line);
                }
                rl.close();
            });
        },
    };
}();

function self(o, e, f) {
    return void 0 === e ? selfProps[o] : void 0 === f ? (void 0 === selfProps[o] && (selfProps.access[o] = "private"), selfProps[o] = e, e) : (selfProps.access[e] = o, selfProps[e] = f, f)
};
var selfProps = {
    access: {
        parent: "private"
    },
    parent: null
};
var $$$parent0 = selfProps;
((typeof foo === "undefined") ? self("foo", ['a', 'b', 'c']) : foo = ['a', 'b', 'c']);
((typeof bar === "undefined") ? self("bar", {
    a: 1,
    length: 1,
    b: 2,
    length: 2,
    c: 3,
    length: 3
}) : bar = {
    a: 1,
    length: 1,
    b: 2,
    length: 2,
    c: 3,
    length: 3
});
((typeof baz === "undefined") ? self("baz", $$$concat([1, 2, 3, 4], [5, 6])) : baz = $$$concat([1, 2, 3, 4], [5, 6]));
((typeof qux === "undefined") ? self("qux", $$$concat({
    a: (typeof foo === "undefined" ? self("foo") : foo),
    length: 1,
    b: (typeof bar === "undefined" ? self("bar") : bar),
    length: 2,
    c: (typeof baz === "undefined" ? self("baz") : baz),
    length: 3
}, {
    d: 4,
    length: 1,
    e: 5,
    length: 2
})) : qux = $$$concat({
    a: (typeof foo === "undefined" ? self("foo") : foo),
    length: 1,
    b: (typeof bar === "undefined" ? self("bar") : bar),
    length: 2,
    c: (typeof baz === "undefined" ? self("baz") : baz),
    length: 3
}, {
    d: 4,
    length: 1,
    e: 5,
    length: 2
}));
(function() {
    var name, val, $$$list = (typeof qux === "undefined" ? self("qux") : qux);
    for (name in $$$list) {
        if ($$$list.hasOwnProperty(name)) {
            val = $$$list[name];
            (function() {
                return (Console.write((typeof name === "undefined" ? self("name") : name), "is", (typeof val === "undefined" ? self("val") : val)));
            }());
        }
    }
}());
(Console.write((typeof name === "undefined" ? self("name") : name), (typeof val === "undefined" ? self("val") : val)));
var data = (Console.read( /*Starting Scope:0*/ (function() {
    var data = ((arguments[0] === void 0) ? (void 0) : arguments[0]);

    function self(o, e, f) {
        return void 0 === e ? selfProps[o] : void 0 === f ? (void 0 === selfProps[o] && (selfProps.access[o] = "private"), selfProps[o] = e, e) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
    var selfProps = {
        access: {
            parent: "private"
        },
        parent: $$$parent0
    };
    var $$$parent1 = selfProps;
    (Console.write("data:", (typeof data === "undefined" ? self("data") : data)));
    return (function() {
        var i, ret = {};
        for (i in selfProps.access) {
            if (selfProps.access[i] === 'public') {
                ret[i] = selfProps[i];
            }
        }
        return ret;
    }())
})));