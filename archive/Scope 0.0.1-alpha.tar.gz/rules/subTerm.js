module.exports = function subTerm (val) {
    return val;
}
