module.exports = function associativeTerm (name, val) {
    return name + ':' + val;
}
