module.exports = function blockStatement (stmt) {
    return stmt;
}
