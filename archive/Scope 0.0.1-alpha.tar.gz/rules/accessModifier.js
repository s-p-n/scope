module.exports = function accessModifier (access) {
    return access;
}
