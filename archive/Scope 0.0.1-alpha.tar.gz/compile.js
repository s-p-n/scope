#!/usr/bin/env node

function scopeAst (name, x) {
    this.name = name;
    this.x = x;
}

function compile (ast) {
    var name = ast.name;
    var args = [];
    var i;
    var arg;
    var result;
    for (i = 0; i < ast.x.length; i += 1) {
        if (typeof ast.x[i] === "string") {
            arg = ast.x[i];
        } else {
            arg = compile(ast.x[i]);
        }
        args.push(arg);
    }
    if (fs.existsSync(__dirname + '/rules/' + name + '.js')) {
        result = require(__dirname + '/rules/' + name).apply(program_data, args);
        if (name === "controlCode") {
            console.log("In ctrl-code:", result.substr(-20));
        }
        return result;
    } else {
        throw '`' + name + '(' + args.join(', ') + ')` is not implemented';
    }
}

// return the indented AST
scopeAst.prototype.get = function get (indent) {
    // create an indentation for level l
    function indentString(l) {
        var r="";
        for(var i=0; i<l; i += 1) {
            r += i + " ";
        }
        return r;
    }

    var r = indentString(indent) + "(" + this.name;
    var rem = this.x;
    if(rem.length == 1 && !(rem[0] instanceof scopeAst)) {
        r += " '"+rem[0]+"'";
    } else for( i in rem ) {
        if( rem[i] instanceof scopeAst ) {
            r += "\n" + rem[i].get(indent+1);
        } else {
            r += "\n" + indentString(indent+1);
            r += "'"+rem[i]+"'";
        }
    }
    return r + /*"\n" + indentString(indent) +*/ ")";
}

var ast, code, hasSlash;
var options = {};
var options_regex = /^[a-z]+\=.*$/;
var args = process.argv.map(function (arg) {
    if (options_regex.test(arg)) {
        options[arg.substr(0, arg.indexOf('='))] =
            arg.substr(arg.indexOf('=')+1, arg.length);
    } else {
        return arg;
    }
});
args.forEach(function (val, i) {
    if (val === void 0) {
        args.splice(i, 1);
    }
});
var scope = require(__dirname + '/scope.js');
var fs = require('fs');
var scope_file = fs.readFileSync(args[2], "utf8");
var pretty = function (code) {
    return require('js-beautify').js_beautify(code, {indent_size: 4});
}
var ugly = function (code) {
    return require('uglify-js').minify(code, {'fromString': true}).code;
}
var filename = args[3] ||
    (
        ((hasSlash = args[2].lastIndexOf('/')) === -1) ?
        args[2] :
        (args[2].substr(
            hasSlash + 1,
            args[2].length - 1
        ))
    ).replace('.sc','.js');
var file = process.cwd() + "/" + filename,
loaded = '',
deps = [],
extensions = function () {
    var extensionsDir = __dirname + '/extensions/',
    notLoaded = [],
    extContainer = {};
    fs.readdirSync(extensionsDir).forEach(function(fileName) {
        if (fileName.indexOf('.js') === -1) {
            return;
        }
        var extName = fileName.substr(0,fileName.indexOf('.'));
        notLoaded.push(extName);
        extContainer[extName] = function() {
            if (notLoaded.indexOf(extName) !== -1) // not loaded
            {
                if (fs.existsSync(extensionsDir + extName + '.node')) {
                    deps.push(extensionsDir + extName + '.node');
                }
                loaded += fs.readFileSync(extensionsDir + extName + '.js', 'utf8');
                notLoaded.splice(notLoaded.indexOf(extName), 1);
            };
            return extName;
        };
    });
    return extContainer;
}(),
program_data = {
    compile: compile,
    curParent: -1,
    parentId: -1,
    lastParent: [-1],
    ext: extensions,
    codePrefix: '',
    codeSuffix: ''
};

scope.parser.yy.scopeAst = scopeAst;
ast = scope.parse(scope_file)

if (options['code'] === 'ast') {
    console.log(ast.get(0));
    return;
}

program_data.parse = scope.parse;
code = compile(ast);
code = loaded +
    program_data.codePrefix +
    code +
    program_data.codeSuffix;

if (options['code'] === "pretty") {
    code = pretty(code);
} else if (options['code'] === "bloated") {

} else {
    code = ugly(code);
}
var i, f;
console.log("deps", deps);
for (i in deps) {
    f = process.cwd() + deps[i].substr(deps[i].lastIndexOf('/'), deps[i].length);

    fs.writeFile(f, fs.readFileSync(deps[i]), function (err) {
        if (err) {
            console.log("Error loading dependency:", err);
        }
        console.log("wrote file:", f);
    });
}

fs.writeFileSync(file, "#!/usr/bin/env node\n" + code);

fs.chmodSync(file, '0755');
console.log("Compiled to " + file);
