module.exports = function invokeParam (args) {
    return args;
}
