module.exports = function controlStatement (stmt) {
    return stmt;
}
