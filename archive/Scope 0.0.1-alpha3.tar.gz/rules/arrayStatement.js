module.exports = function arrayStatement(arr) {
    if (arr.substr(0,3) === 'obj') {
        return '{' + arr.substr(3,arr.length) + '}';
    }
    return '[' + arr + ']';
}
