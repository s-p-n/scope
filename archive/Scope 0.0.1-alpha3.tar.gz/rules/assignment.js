module.exports = function assignment (a) {
    return a;
}
