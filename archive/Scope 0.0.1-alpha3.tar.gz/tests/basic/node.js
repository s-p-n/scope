#!/usr/bin/env node
var Console = function() {
    return {
        write: function() {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        },
        read: require('./Console').read,
    };
}();

function self(o, e, f) {
    return void 0 === e ? selfProps[o] : void 0 === f ? (void 0 === selfProps[o] && (selfProps.access[o] = "private"), selfProps[o] = e, e) : (selfProps.access[e] = o, selfProps[e] = f, f)
};
var selfProps = {
    access: {
        parent: "private"
    },
    parent: null
};
var $$$parent0 = selfProps;
var a = "hi";
var b = 2;
var c = 34;
(((typeof Console !== 'object' || Console instanceof Array) ? (function() {
    throw "Cannot get/set property `write` onto a `Non-instance` on line: 5";
    return false
}()) : Console).write());