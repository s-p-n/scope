#!/usr/bin/env node
function self(o, e, f) {
    return void 0 === e ? selfProps[o] : void 0 === f ? (void 0 === selfProps[o] && (selfProps.access[o] = "private"), selfProps[o] = e, e) : (selfProps.access[e] = o, selfProps[e] = f, f)
};
var selfProps = {
    access: {
        parent: "private"
    },
    parent: null
};
var $$$parent0 = selfProps;
return 8 + 120 * 2 / (function() {
    var i;
    var r = 5;
    for (i = 1; i < 5; i += 1) {
        r *= i;
    }
    return r;
}());