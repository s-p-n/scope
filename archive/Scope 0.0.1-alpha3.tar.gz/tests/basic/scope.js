#!/usr/bin/env node
var Console = function() {
    return {
        write: function() {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        },
        read: require('./Console').read,
    };
}();
var $$$runtimeError = function(line, msg, what) {
    throw new Error(
        "\033[31m\033[1m Runtime Error:\033[0m\033[1m " +
        msg.replace(/%what%/g, what).replace(/%red%/g, '\033[31m').replace(/%default%/g, '\033[0m\033[1m').replace(/%green%/g, '\033[32m') +
        "\033[1m on line: \033[31m" + line + '\033[0m');
}
var Type = function Type(primitive) {
    if (primitive instanceof Array) {
        return "array";
    }
    switch (typeof primitive) {
        case "string":
            return "text";
        case "function":
            return "scope";
        case "object":
            return "instance";
    }
    return typeof primitive;
}

    function self(o, e, f) {
        return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
var selfProps = {
    access: {
        parent: "private"
    },
    parent: null
};
var $$$parent0 = selfProps;
( /*Starting Scope:0*/ (function() {
    var some = ((arguments[0] === void 0) ? (void 0) : arguments[0]),
        args = ((arguments[1] === void 0) ? (void 0) : arguments[1]),
        here = ((arguments[2] === void 0) ? (void 0) : arguments[2]);

    function self(o, e, f) {
        return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
    var selfProps = {
        access: {
            parent: "private"
        },
        parent: $$$parent0
    };
    var $$$parent1 = selfProps;
    (((Type(Console) !== 'instance') ? ($$$runtimeError(3, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).write(((typeof some === "undefined" || root.some === some) ? self("some", 3) : some), ((typeof args === "undefined" || root.args === args) ? self("args", 3) : args), ((typeof here === "undefined" || root.here === here) ? self("here", 3) : here)));
    return (function() {
        var i, ret = {};
        for (i in selfProps.access) {
            if (selfProps.access[i] === 'public') {
                ret[i] = selfProps[i];
            }
        }
        return ret;
    }())
})("foo", "bar", "baz"));
var Foo = /*Starting Scope:0*/ (function() {
    function self(o, e, f) {
        return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
    var selfProps = {
        access: {
            parent: "private"
        },
        parent: $$$parent0
    };
    var $$$parent2 = selfProps;
    self("private", "baz", "woohoo!");
    self("public", "bar", "testing properties..");
    self("public", "getBaz", /*Starting Scope:2*/ (function() {
        function self(o, e, f) {
            return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
        };
        var selfProps = {
            access: {
                parent: "private"
            },
            parent: $$$parent2
        };
        var $$$parent3 = selfProps;
        (((Type(Console) !== 'instance') ? ($$$runtimeError(11, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).write(((typeof parent === "undefined" || root.parent === parent) ? self("parent", 11) : parent)));
        return ((Type(((typeof parent === "undefined" || root.parent === parent) ? self("parent", 12) : parent)) !== 'instance') ? ($$$runtimeError(12, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(((typeof parent === "undefined" || root.parent === parent) ? self("parent", 12) : parent)) + '%default% given', ((typeof parent === "undefined" || root.parent === parent) ? self("parent", 12) : parent))) : ((typeof parent === "undefined" || root.parent === parent) ? self("parent", 12) : parent)).baz;
        return (function() {
            var i, ret = {};
            for (i in selfProps.access) {
                if (selfProps.access[i] === 'public') {
                    ret[i] = selfProps[i];
                }
            }
            return ret;
        }())
    }));
    return (function() {
        var i, ret = {};
        for (i in selfProps.access) {
            if (selfProps.access[i] === 'public') {
                ret[i] = selfProps[i];
            }
        }
        return ret;
    }())
});
var bar = /*Starting Scope:0*/ (function() {
    function self(o, e, f) {
        return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
    var selfProps = {
        access: {
            parent: "private"
        },
        parent: $$$parent0
    };
    var $$$parent4 = selfProps;
    (((Type(Console) !== 'instance') ? ($$$runtimeError(18, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).write("What is your name?"));
    return "Name is " + (((Type(Console) !== 'instance') ? ($$$runtimeError(19, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).read());
    return (function() {
        var i, ret = {};
        for (i in selfProps.access) {
            if (selfProps.access[i] === 'public') {
                ret[i] = selfProps[i];
            }
        }
        return ret;
    }())
});
var foo = (((typeof Foo === "undefined" || root.Foo === Foo) ? self("Foo", 21) : Foo)());
(((Type(Console) !== 'instance') ? ($$$runtimeError(22, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).write("foo.baz is:", (((Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 22) : foo)) !== 'instance') ? ($$$runtimeError(22, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 22) : foo)) + '%default% given', ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 22) : foo))) : ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 22) : foo)).getBaz())));
var baz = [1, 2, 3];
((Type(((typeof far === "undefined" || root.far === far) ? self("far", 27) : far)) !== 'instance') ? ($$$runtimeError(27, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(((typeof far === "undefined" || root.far === far) ? self("far", 27) : far)) + '%default% given', ((typeof far === "undefined" || root.far === far) ? self("far", 27) : far))) : ((typeof far === "undefined" || root.far === far) ? self("far", 27) : far)).omg = "text";
((Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 29) : foo)) !== 'instance') ? ($$$runtimeError(29, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 29) : foo)) + '%default% given', ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 29) : foo))) : ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 29) : foo)).hack = /*Starting Scope:0*/ (function() {
    function self(o, e, f) {
        return void 0 === f ? selfProps[o] || (($$$runtimeError(e, '%default%Reference to undefined property or variable %red%%what%%default%', o))) : (selfProps.access[e] = o, selfProps[e] = f, f)
    };
    var selfProps = {
        access: {
            parent: "private"
        },
        parent: $$$parent0
    };
    var $$$parent5 = selfProps;
    return ((typeof this === "undefined" || root.this === this) ? self("this", 30) : this);
    return (function() {
        var i, ret = {};
        for (i in selfProps.access) {
            if (selfProps.access[i] === 'public') {
                ret[i] = selfProps[i];
            }
        }
        return ret;
    }())
});
(((Type(Console) !== 'instance') ? ($$$runtimeError(33, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(Console) + '%default% given', Console)) : Console).write((((Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 33) : foo)) !== 'instance') ? ($$$runtimeError(33, '%default%Only the %green%instance%default% type may contain properties, %red%' + Type(((typeof foo === "undefined" || root.foo === foo) ? self("foo", 33) : foo)) + '%default% given', ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 33) : foo))) : ((typeof foo === "undefined" || root.foo === foo) ? self("foo", 33) : foo)).hack())));