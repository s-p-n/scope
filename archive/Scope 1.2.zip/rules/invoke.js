module.exports = function invoke (func, args) {
    return '(' + func + '(' + args + ')' + ')';
}
