var scope = require('./scope.js');
var fs = require('fs');
function jisonAST (name, x) {
    this.name = name;
    this.x = x;
}

function compile (ast) {
    var name = ast.name;
    var args = [];
    var i;
    var arg;
    for (i = 0; i < ast.x.length; i += 1) {
        if (typeof ast.x[i] === "string") {
            arg = ast.x[i];
        } else {
            arg = compile(ast.x[i]);
        }
        args.push(arg);
    }
    if (fs.existsSync('./rules/' + name + '.js')) {
        return require('./rules/' + name).apply(null, args);
    } else {
        throw '`' + name + '(' + args.join(', ') + ')` is not implemented';
    }
}

// return the indented AST
jisonAST.prototype.get = function get (indent) {
    // create an indentation for level l
    function indentString(l) {
        var r="";
        for(var i=0; i<l; i += 1) {
            r += i + " ";
        }
        return r;
    }

    var r = indentString(indent) + "(" + this.name;
    var rem = this.x;
    if(rem.length == 1 && !(rem[0] instanceof jisonAST)) {
        r += " '"+rem[0]+"'";
    } else for( i in rem ) {
        if( rem[i] instanceof jisonAST ) {
            r += "\n" + rem[i].get(indent+1);
        } else {
            r += "\n" + indentString(indent+1);
            r += "'"+rem[i]+"'";
        }
    }
    return r + /*"\n" + indentString(indent) +*/ ")";
}
scope.parser.yy.jisonAST = jisonAST;
var ast = scope.parse(
    fs.readFileSync(process.argv[2], "utf8")
);
var code = compile(ast);
console.log("JavaScript code:", compile(ast));
console.log("\n\tRunning..\n------------------\n");
eval(code);
console.log("\n------------------\n\tFin.");
/*
console.log(JSON.stringify(ast, null, ' '));

console.log(scope.parse(
    fs.readFileSync(process.argv[2], "utf8")
).get(0));

*/
