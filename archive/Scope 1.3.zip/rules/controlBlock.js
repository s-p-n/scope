module.exports = function controlBlock (stmt, controlBlock) {
    if (stmt === void 0) {
        return "";
    }

    return stmt + ';' + controlBlock;
}
