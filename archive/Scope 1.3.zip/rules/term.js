module.exports = function term (a, b, c) {
    switch (a) {
        case 'not':
            return '!' + b;
        case '!':
            return '(function (){' +
                'var i;' +
                'var r = ' + b + ';' +
                ((b[0] === '-') ?
                    'for(i=-1;i>' + b + ';i-=1){':
                    'for(i=1;i<' + b + ';i+=1){'
                ) +
                    'r*=i;' +
                '}' +
                'return r;' +
            '}())';
        case '-':
            return '-' + b;
    }
    switch (b) {
        case '+':
            return a + b + c;
        case '-':
            return a + b + c;
        case '*':
            return a + b + c;
        case '/':
            return a + b + c;
        case 'is':
            return a + '===' + c;
        case 'isnt':
            return a + '!==' + c;
        case '&':
            return a + '+' + c;
            /*
            var result, shortest, i;
            if (
                !(typeof a === "string" && typeof c === "string") &&
                !(typeof a === "object" && typeof c === "object")
            ) {
                throw "Both types must be the same (either string or array)";
            }
            if (typeof a === "string") {
                result = a + '+' + c;
            } else {
                if(a instanceof Array) {
                    for (i = 0; i < c.length; i += 1) {
                        a.push(c[i]);
                    }
                    result = a;
                } else {
                    console.log("length of assoc:", a.length);
                    if (a.length > c.length) {
                        result = a;
                        shortest = c;
                    } else {
                        result = c;
                        shortest = a;
                    }
                    console.log("Shortest:", shortest);
                    for (i in shortest) {
                        console.log("Looping:", i);
                        if(shortest.hasOwnProperty(i)) {
                            result[i] = shortest[i];
                            result.length += 1;
                        }
                    }
                }
            }
            return result;
            */
    }
    return a;
}
