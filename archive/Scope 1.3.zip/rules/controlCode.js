module.exports = function controlCode (stmt, controlCode) {
    if (stmt === void 0) {
        return "";
    }

    return stmt + ';' + controlCode;
}
