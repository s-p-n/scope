var Variables = {
    Console: {
        write: function () {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        }
    }
};
module.exports = function identifier (name, id) {
    if (name in Variables) {
        name = Variables[name];
    }

    if (id === void 0) {
        return name;
    }

    return name[id]
}
