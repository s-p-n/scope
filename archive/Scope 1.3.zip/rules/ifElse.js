module.exports = function ifElse (ifBegin, controlBlock, ifElse) {
    var conditionEnd = 'return ret;}())';
    var ifEnd = '}());}';
    if (controlBlock === void 0) {
        return ifBegin + ifEnd + conditionEnd;
    }
    return ifEnd + ' else ' + ifBegin + controlBlock + ifElse;
}
