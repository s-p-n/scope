module.exports = function identifier (id, name, isArr) {
    if (name !== void 0) {
        if (name === "__proto__" ||
            name === "prototype") {
                name  = '$' + name;
        }
        if (isArr !== void 0) {
            return id + '[' + name + ']';
        }

        return "((typeof " + id + " !== 'object' || " +
            id + " instanceof Array) ? " +
             '(function () {throw "Cannot get/set property `'+ name +'` onto a `Non-instance` on line: ' + this.line + '";return false}())' +
             ':' + id + ').' + name;
    }

    if (id in this.ext) {
        return this.ext[id]();
    }
    return '((typeof '+id+' === "undefined" || root.'+id+' === '+id+') ? self("'+id+'") : '+id+')';
}
