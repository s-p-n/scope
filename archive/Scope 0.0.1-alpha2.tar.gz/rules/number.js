module.exports = function number (n) {
    return n;
}
