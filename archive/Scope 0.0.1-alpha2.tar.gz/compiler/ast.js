var scopeAst = function scopeAst (line, name, x) {
    this.name = name;
    this.x = x;
    this.line = line + 1;
}

// create an indentation for level l
function indentString(l) {
    var r="";
    var i;
    for(i = 0; i < l; i += 1) {
        r += i + " ";
    }
    return r;
}

scopeAst.prototype.get = function get (indent) {
    var r = indentString(indent) + "(" + this.name;
    var rem = this.x;
    if(rem.length == 1 && !(rem[0] instanceof scopeAst)) {
        r += " '"+rem[0]+"'";
    } else for( i in rem ) {
        if( rem[i] instanceof scopeAst ) {
            r += "\n" + rem[i].get(indent+1);
        } else {
            r += "\n" + indentString(indent+1);
            r += "'"+rem[i]+"'";
        }
    }
    return r + /*"\n" + indentString(indent) +*/ ")";
}

module.exports = scopeAst;
