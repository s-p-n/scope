var fs = require('fs');
module.exports = function (program_data) {
    return function compile (ast) {
        var name = ast.name;
        var args = [];
        var i;
        var arg;
        var result;
        for (i = 0; i < ast.x.length; i += 1) {
            if (typeof ast.x[i] === "string") {
                arg = ast.x[i];
            } else {
                arg = compile(ast.x[i]);
            }
            args.push(arg);
        }
        program_data.line = ast.line;
        if (fs.existsSync(__dirname + '/../rules/' + name + '.js')) {
            result = require(__dirname + '/../rules/' + name).apply(program_data, args);
            return result;
        } else {
            throw '`' + name + '(' + args.join(', ') + ')` is not implemented';
        }
    };
};
