module.exports = function syntax () {

}
