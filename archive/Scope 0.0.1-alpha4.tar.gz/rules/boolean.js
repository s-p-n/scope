module.exports = function boolean (val) {
    return val;
}
