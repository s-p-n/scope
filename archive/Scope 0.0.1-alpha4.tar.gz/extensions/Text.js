var Text = function Text (primitive) {
    return primitive.toString();
}
