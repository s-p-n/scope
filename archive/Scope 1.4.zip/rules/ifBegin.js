module.exports = function ifBegin (condition) {
    return "(function () {var ret = " + condition + ";if (ret){(function () {";
}
