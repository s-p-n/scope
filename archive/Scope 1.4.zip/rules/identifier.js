var Variables = {
    Console: {
        write: function () {
            console.log.apply(null, Array.prototype.slice.call(arguments, arguments));
        }
    }
};
module.exports = function identifier (id, name) {
    if (name !== void 0) {
        if (typeof id === "object") {
            if (name in id) {
                return id[name];
            } else {
                throw '"'+name+'" is not a member of "' + id + '"';
            }
        }
        return id + '.' + name;
    }
    if (id in Variables) {
        return Variables[id];
    }
    return '(typeof '+id+' === "undefined" ? self("'+id+'") : '+id+')';
}
