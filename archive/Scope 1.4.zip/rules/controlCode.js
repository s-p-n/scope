module.exports = function controlCode (controlCode, stmt) {
    if (controlCode === void 0) {
        return 'var selfProps = {access:{}};' +
            'function self (a,b,c) {' +
                'if (b === void 0) {' +
                    'return selfProps[a];' +
                '}' +
                'if (c === void 0) {' +
                    'if (selfProps[a] === void 0) {' + //short-declare
                        'selfProps["access"][a] = "private";' +
                    '}' +
                    'selfProps[a] = b;' +
                    'return b;' +
                '}' +
                'selfProps["access"][b] = a;' +
                'selfProps[b] = c;' +
                'return c;' +
            '};';
    }

    return controlCode + stmt + ';';
}
