module.exports = function text (txt) {
    return txt;
}
